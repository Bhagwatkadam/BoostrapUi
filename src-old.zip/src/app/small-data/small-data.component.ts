import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-small-data',
  template: `
    <p>
      small-data works!
    </p>
  `,
  styles: [
  ]
})
export class SmallDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
