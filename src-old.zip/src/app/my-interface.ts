export interface MyInterface {
    myinterfaceFuntion(val1: any, val2: any): any
}
