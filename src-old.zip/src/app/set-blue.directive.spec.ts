import { SetBlueDirective } from './set-blue.directive';

describe('SetBlueDirective', () => {
  it('should create an instance', () => {
    // const directive = new SetBlueDirective();
    // expect(directive).toBeTruthy();
  });
});
