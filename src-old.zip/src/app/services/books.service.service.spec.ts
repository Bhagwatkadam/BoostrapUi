import { TestBed } from '@angular/core/testing';

import {GoogleBooksService } from './books.service.service';

describe('Books.ServiceService', () => {
  let service: GoogleBooksService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GoogleBooksService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
