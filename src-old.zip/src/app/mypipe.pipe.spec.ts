import { MypipePipe } from './mypipe.pipe';

describe('MypipePipe', () => {
  it('create an instance', () => {
    const pipe = new MypipePipe();
    expect(pipe).toBeTruthy();
  });
});
