import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AboutComponent } from './about/about.component';
import { ChildDataComponent } from './child-data/child-data.component';
import { SmallDataComponent } from './small-data/small-data.component';
import { NavComponent } from './nav/nav.component';
import { LayoutComponent } from './layout/layout.component';
import { LocationComponent } from './location/location.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { ParentComponent } from './parent/parent.component';
import { SetBlueDirective } from './set-blue.directive';
import { RedcolorDirective } from './redcolor.directive';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReactiveComponent } from './reactive/reactive.component';
import { TemplateFormComponent } from './template-form/template-form.component';
import { CounterComponent } from './counter/counter.component';
import { EmpComponent } from './emp/emp.component';
import { SearchPipe } from './search.pipe';
import { ProductlistComponent } from './productlist/productlist.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { StoreModule } from '@ngrx/store';
import { counterReducer } from './ngrx/reducer/counter.reducer';
import { collectionReducer } from './ngrx/reducer/collection.reducer';
import { booksReducer } from './ngrx/reducer/books.reducer';
import { BookListComponent } from './book-list/book-list.component';
import { BookCollectionComponent } from './book-collection/book-collection.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AboutComponent,
    ChildDataComponent,
    SmallDataComponent,
    NavComponent,
    LayoutComponent,
    LocationComponent,
    HomeComponent,
    ContactComponent,
    ParentComponent,
    SetBlueDirective,
    RedcolorDirective,
    ReactiveComponent,
    TemplateFormComponent,
    CounterComponent,
    EmpComponent,
    SearchPipe,
    ProductlistComponent,
    ProductDetailComponent,
    BookListComponent,
    BookCollectionComponent,   
    // MypipePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    StoreModule.forRoot({count: counterReducer,books: booksReducer, collection: collectionReducer }, {})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
