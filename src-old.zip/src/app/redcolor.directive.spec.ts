import { ElementRef } from "@angular/core";
import { RedcolorDirective } from "./redcolor.directive";

describe('RedcolorDirective', () => {
  it('should create an instance', () => {
    // const directive = new RedcolorDirective();
    // expect(directive).toBeTruthy();
  });
});
