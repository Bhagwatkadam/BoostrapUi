<ng-content>
<ng-container>
<div *ngIf="istrue else ElesPart> dfdsf</div>
<ng-template #ElesPart> ElesPart data </ng-template>
<ng-template #myTemp> div h1 </ng-template>
<div *templateOutlet=""> </div>
------
Decorative
Component (LCH)
Pipe 
@pipe(){
    name:'dsfds'
}
Directive
Form

model  =		
export class Model {
    param1: string;
	param2: string;
	param3: number;
	arr: number[];
}
Import { Model } from './model';
public model: Model = {param1:'wewe" , param2:'dsfs', param3: 10, arr:[1,2,3,'ee']};

interface
extends 